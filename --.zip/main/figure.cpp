#include "figure.h"
#include<QPoint>
#include<QPixmap>
#include <QObject>
#include<QPainter>
Figure::Figure(QPoint pos,QString File):pixmap(File)
{
 _pos=pos;
}
void Figure::draw(QPainter *painter)
{
    painter->drawPixmap(_pos,pixmap);
}
