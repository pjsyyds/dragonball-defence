#ifndef FIGURE_H
#define FIGURE_H
#include<QPainter>
#include <QObject>
#include<QPoint>
#include<QPixmap>
class Figure
{
public:
    Figure(QPoint pos,QString File);
    void draw(QPainter *painter);
private:
      QPoint _pos;
     QPixmap pixmap;
};

#endif // FIGURE_H
