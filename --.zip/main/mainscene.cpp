#include "mainscene.h"
#include "ui_mainscene.h"
#include<QPushButton>
#include<QMainWindow>
#include<QPainter>
#include<QPaintEvent>
#include<QPushButton>
#include<QPoint>
MainScene::MainScene(QWidget *parent) :QMainWindow(parent), ui(new Ui::MainScene)
{this->setFixedSize(700,500);
    ui->setupUi(this);
    QPushButton*(setfigure)=new QPushButton(this);
    setfigure->setParent(this);
    setfigure->setFixedSize(30,30);
    setfigure->move(230,320);
    connect(setfigure,&QPushButton::clicked,this,&MainScene::set_figure);
}

MainScene::~MainScene()
{
    delete ui;
}
void MainScene::set_figure()
{
Figure *new_figure=new Figure(QPoint(230,320),":/tpstart button");
figure_list.push_back(new_figure);
}
