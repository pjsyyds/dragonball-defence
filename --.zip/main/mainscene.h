#ifndef MAINSCENE_H
#define MAINSCENE_H

#include <QMainWindow>
#include <QList>
#include"figure.h"
namespace Ui {
class MainScene;
}

class MainScene : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainScene(QWidget *parent = nullptr);
    ~MainScene();
    void set_figure();
private:
    Ui::MainScene *ui;
    QList<Figure *>  figure_list;
};

#endif // MAINSCENE_H
