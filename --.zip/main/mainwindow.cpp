#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QMainWindow>
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>
#include<QDebug>
#include"mainscene.h"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{   this->setFixedSize(960,550);
    ui->setupUi(this);
    QPushButton*(bt)=new QPushButton(this);
    bt->setFixedSize(100,40);
    bt->move(200,400);
    bt->setText("start");
    MainScene * sce = new MainScene;
    connect(bt,&QPushButton::clicked,this,[=](){
        this->close();
        sce->show();
    });
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent*)
{
QPainter painter(this);

painter.drawPixmap(0, 0, QPixmap(":/tpbg.bmp"));
}

