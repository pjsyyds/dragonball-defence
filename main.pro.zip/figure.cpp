#include "Figure.h"
#include <QVector>
int Figure::GetX() const
{
    return mx;
}

int Figure::GetY() const
{
    return my;
}

int Figure::GetWidth() const
{
    return width;
}

int Figure::GetHeight() const
{
    return height;
}


QString Figure::GetBaseImgPath() const
{
    return BaseImgPath;
}

QString Figure::GetDefImgPath() const
{
    return DefImgPath;
}

int Figure::GetUpLeftX() const
{
    return UpLeftX;
}

int Figure::GetUpLeftY() const
{
    return UpLeftY;
}


int Figure::GetRange() const
{
    return Range;
}

Monster* Figure::GetAimsMonster() const
{
    return aimsmon;
}

void Figure::SetAimsMonster(Monster* mon)
{
    aimsmon = mon;
}

QString Figure::GetBulletPath() const
{
    return BullPath;
}

QVector<BulletStr*>& Figure::GetBulletVec()
{
    return BulletVec;
}

void Figure::InterBullet()
{
    counter++;

    if(counter < 8 || !aimsmon)
        return;

    BulletStr *bl = new BulletStr(CoorStr(UpLeftX + 40, UpLeftY + 40));

    bl->coor.x = UpLeftX + 40;
    bl->coor.y = UpLeftY + 40;


    if((!(aimsmon->GetX() - bl->coor.x)))
    {
        delete bl;
        bl = nullptr;
        goto L1;
    }

    bl->k = (aimsmon->GetY() - bl->coor.y) / (aimsmon->GetX() - bl->coor.x);
    bl->b = aimsmon->GetY() - aimsmon->GetX() * bl->k;

    bl->coor.x = UpLeftX + 40;
    bl->coor.y = UpLeftY + 40;

    BulletVec.push_back(bl);

    if(aimsmon->GetX() <= UpLeftX + 40)     //确定子弹的移动方向
        bl->dirflag = true;
    L1:

    counter = 0;    //计数器重置为0

}

void Figure::BulletMove()         //子弹移动
{

    for(auto bulli : BulletVec)
    {
        const int speed = 15;

        bulli->dirflag ? bulli->coor.x -= speed : bulli->coor.x += speed;

        bulli->coor.y = bulli->k * bulli->coor.x + bulli->b;
    }


}

int Figure::GetBulletWidth() const{
    return bullwidth;
}

int Figure::GetBulletHeight() const
{
    return bullheight;
}

int Figure::GetAttack() const
{
    return attack;
}

void Figure::SetAttack(int attack)
{
    this->attack = attack;
}

void Figure::SetWidthHeight(int width, int height)
{
    this->width = width;
    this->height = height;
}

void Figure::SetXY(int x, int y)
{
    this->mx = x;
    this->my = y;
}

int& Figure::SetRange()
{
    return Range;
}


void Figure::SetBulletWidthHeight(int width, int height){
    bullwidth = width;
    bullheight = height;
}











