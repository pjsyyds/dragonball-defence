#ifndef FIGURE_H
#define FIGURE_H

#include <QString>
#include "monster.h"

class Figure
{
protected:
    int mx, my;
    int width, height;
    QString BaseImgPath;
    QString DefImgPath;
    int UpLeftX, UpLeftY;
    int Range;

    Monster* aimsmon = nullptr;

    QString BullPath;
    int power;
    int bullwidth, bullheight;
    QVector<BulletStr*> BulletVec;
    int counter = 0;
    int attack;

public:
    int GetX() const;
    int GetY() const;
    int GetWidth() const;
    int GetHeight() const;
    QString GetBaseImgPath() const;
    QString GetDefImgPath() const;
    int GetUpLeftX() const;
    int GetUpLeftY() const;
    int GetRange() const;

    Monster* GetAimsMonster() const;
    void SetAimsMonster(Monster*);

    QString GetBulletPath() const;
    QVector<BulletStr*>& GetBulletVec();
    void InterBullet();
    void BulletMove();
    int GetBulletWidth() const;
    int GetBulletHeight() const;
    int GetAttack() const;

    void SetAttack(int);
    void SetWidthHeight(int, int);
    void SetXY(int, int);
    int& SetRange();

    void SetBulletWidthHeight(int, int);
};

#endif // FIGURE_H
