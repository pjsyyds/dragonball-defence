#include "fposition.h"


Fposition::Fposition(int x, int y, int width, int height)
    : mx(x), my(y), mwidth(width), mheight(height) {}

int Fposition::GetX() const
{
    return mx;
}

int Fposition::GetY() const
{
    return my;
}

int Fposition::GetWidth() const
{
    return mwidth;
}

int Fposition::GetHeight() const
{
    return mheight;
}

