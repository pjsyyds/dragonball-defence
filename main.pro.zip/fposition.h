#ifndef FPOSITION_H
#define FPOSITION_H

#include <QVector>

//塔基
class Fposition
{
private:
    const int mx, my;
    const int mwidth, mheight;
public:

    Fposition(int x, int y, int width = 80, int height = 80);

    int GetX() const;
    int GetY() const;
    int GetWidth() const;
    int GetHeight() const;
};

#endif // FPOSITION_H
