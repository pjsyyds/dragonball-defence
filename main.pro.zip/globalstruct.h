#ifndef GLOBALSTRUCT_H
#define GLOBALSTRUCT_H

#include <QString>


struct SubbutStr
{
    int SubX;
    int SubY;
    int SubWidth = 56;
    int SubHeight = 56;
    QString SubImgPath;
};


struct CoorStr
{
    int x;
    int y;

    CoorStr(int x1, int y1) : x(x1), y(y1) {}
};

//子弹结构
struct BulletStr
{
    CoorStr coor;
    int k = 0, b = 0;  //子弹路径
    bool dirflag = false;

    BulletStr(CoorStr fcoor) : coor(fcoor) {}

    int GetX()  const
    {
        return coor.x;
    }

    int GetY() const
    {
        return coor.y;
    }
};

#endif // GLOBALSTRUCT_H
