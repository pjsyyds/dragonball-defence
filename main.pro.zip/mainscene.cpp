#include "mainscene.h"
#include "ui_mainscene.h"
#include<QPushButton>
#include<QMainWindow>
#include<QPainter>
#include<QPaintEvent>
#include<QPushButton>
#include<QPoint>
#include<QTimer>
#include <QDebug>
#include <cmath>
#include<goku.h>
#include <QPushButton>

//计算两点之间距离
#define Distance(X1, Y1, X2, Y2)           \
abs(sqrt((((X1) - (X2)) * ((X1) - (X2))) + (((Y1) - (Y2)) * ((Y1) - (Y2)))))


inline bool MainScene::DeductionMoney(int money)
{
    if (this->money - money < 0) return true; //判断金钱是否足够
    this->money -= money;
    moneylable->setText(QString("金钱：%1").arg(this->money)); //刷新标签文本
    return false;
}

MainScene::MainScene(QWidget *parent) :QMainWindow(parent), ui(new Ui::MainScene)
{

    setFixedSize(1040, 640);
    ui->setupUi(this);
    QTimer* timer2 = new QTimer(this);      //定时器
    timer2->start(2000);


//    setMouseTracking(true);


    moneylable->move(20, 40);
    setStyleSheet("color:white");
    moneylable->setFont(QFont("微软雅黑", 24));
    moneylable->setText(QString("金钱：%1").arg(money));

    //生命
    QLabel *lifelable = new QLabel(this);
    lifelable->setGeometry(20, 100, 220, 40);
    lifelable->setFont(QFont("微软雅黑", 24));
    lifelable->setText(QString("生命：%1").arg(life));

    QTimer* timer = new QTimer(this);
    timer->start(120);

    connect(timer,&QTimer::timeout,[=]()
    {

        for (auto target : DefeTowerVec)
        {
            if (!target->GetAimsMonster())
            {
                for(int i = MonsterVec.size() - 1; i >= 0; i--)

                    if (Distance(target->GetUpLeftX() + 40, target->GetUpLeftY() + 40,
                        MonsterVec.at(i)->GetX() + (MonsterVec.at(i)->GetWidth() >> 1),
                        MonsterVec.at(i)->GetY() + (MonsterVec.at(i)->GetHeight() >> 1)) <= target->GetRange())
                    {
                        target->SetAimsMonster(MonsterVec.at(i));
                        break;
                    }
            }
            else
                if (Distance(target->GetUpLeftX() + 40, target->GetUpLeftY() + 40,
                    target->GetAimsMonster()->GetX() + (target->GetAimsMonster()->GetWidth() >> 1),
                    target->GetAimsMonster()->GetY() + (target->GetAimsMonster()->GetHeight() >> 1)) <= target->GetRange())
                {

                     target->InterBullet();
                }
            if (target->GetAimsMonster())
                if (Distance(target->GetUpLeftX() + 40, target->GetUpLeftY() + 40,
                    target->GetAimsMonster()->GetX() + (target->GetAimsMonster()->GetWidth() >> 1),
                    target->GetAimsMonster()->GetY() + (target->GetAimsMonster()->GetHeight() >> 1)) > target->GetRange())
                        target->SetAimsMonster(NULL);     //超过距离将目标怪物设为空
        }

        //子弹移动
        for (auto target : DefeTowerVec)
            target->BulletMove();

        //怪物移动
        for (auto Moni = MonsterVec.begin(); Moni != MonsterVec.end(); Moni++)
            if((*Moni)->Move())
            {
                delete *Moni;
                MonsterVec.erase(Moni);

                life--;
                lifelable->setText(QString("生命：%1").arg(life));

                if (life <= 0) this->close();

                break;
            }


        for (auto target : DefeTowerVec)
        {
            auto &tbullvec = target->GetBulletVec();    //临时存储子弹
            for (auto bullit = tbullvec.begin(); bullit != tbullvec.end(); bullit++)    //子弹
                for (auto monit = MonsterVec.begin(); monit != MonsterVec.end(); monit++)//怪物
                    if ((*bullit)->GetX() + (target->GetBulletWidth() >> 1) >= (*monit)->GetX() && (*bullit)->GetX() <= (*monit)->GetX() + (*monit)->GetWidth() &&
                       (*bullit)->GetY() + (target->GetBulletHeight() >> 1) >= (*monit)->GetY() && (*bullit)->GetY() <= (*monit)->GetY() + (*monit)->GetHeight())
                    {   //击中怪物时
                        tbullvec.erase(bullit);     //删除子弹

                        (*monit)->SetHealth((*monit)->GetHealth() - target->GetAttack());

                        if ((*monit)->GetHealth() <= 0) //生命值为空时
                        {
                            for (auto target2 : DefeTowerVec)
                                if (target2->GetAimsMonster() == *monit)
                                    target2->SetAimsMonster(NULL);

                            MonsterVec.erase(monit);
                            money += RewardMoney;
                            moneylable->setText(QString("金钱：%1").arg(money));
                        }
                        goto L1;
                    }
            L1:;
        }


        update();
    });
}

//画出防御塔
void MainScene::DrawDefenseTower(QPainter& painter)
{
    //画出防御塔
    for (auto target : DefeTowerVec)  //遍历防御塔数组
    {
        //画出底座
        painter.drawPixmap(target->GetUpLeftX(), target->GetUpLeftY(), 80, 80, QPixmap(target->GetBaseImgPath()));


        //画出所有防御塔子弹
        for (auto bulli : target->GetBulletVec())
            painter.drawPixmap(bulli->coor.x, bulli->coor.y, target->GetBulletWidth(), target->GetBulletHeight(),QPixmap(target->GetBulletPath()));

        painter.drawPixmap(target->GetX(), target->GetY(), target->GetWidth(), target->GetHeight(), QPixmap(target->GetDefImgPath())/*图片路径*/);

        painter.resetTransform();   //重置调整
    }
}


void MainScene::DrawMonster(QPainter& painter)
{
    for (auto moni : MonsterVec)//画出怪物
        painter.drawPixmap(moni->GetX(), moni->GetY(), moni->GetWidth(), moni->GetHeight(), QPixmap(moni->GetImgPath()));
}


void MainScene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);
    DrawDefenseTower(painter);
    DrawMonster(painter);
}


//析构释放内存
MainScene::~MainScene()
{
    //释放防御塔坑指针数组TowerPitVec
    for (auto it = TowerPitVec.begin(); it != TowerPitVec.end(); it++)
    {
        delete *it;
        *it = NULL;
    }

    //释放防御塔父类指针数组DefeTowerVec
    for (auto it = DefeTowerVec.begin(); it != DefeTowerVec.end(); it++)
    {
        delete *it;
        *it = NULL;
    }

    //释放怪物数组MonsterVec
    for (auto it = MonsterVec.begin(); it != MonsterVec.end(); it++)
    {
        delete *it;
        *it = NULL;
    }

}

