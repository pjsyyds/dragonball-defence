#ifndef MAINSCENE_H
#define MAINSCENE_H
#include<QLabel>
#include <QWidget>
#include <QPainter>
#include <QMouseEvent>
#include <QTimer>
#include "fposition.h"
#include "figure.h"
#include "monster.h"
#include <QLabel>
#include<QMainWindow>
namespace Ui {
class MainScene;
}

class MainScene : public QMainWindow
{
    Q_OBJECT
private:
     Ui::MainScene *ui;
    QVector<Fposition*> TowerPitVec;
    QVector<Figure*> DefeTowerVec;
    QVector<Monster*> MonsterVec;
    void paintEvent(QPaintEvent *);
    void DrawMapArr(QPainter&);
    void DrawDefenseTower(QPainter&);
    void DrawMonster(QPainter&);
    int money = 1000;   //金钱
    QLabel *moneylable = new QLabel(this);   //显示金钱标签

    inline bool DeductionMoney(int);         //判断金钱

    int life = 10;      //生命

    int counter = 0;    //怪物计数

    const int RewardMoney = 20;


public:
    ~MainScene();
    explicit MainScene(QWidget *parent = nullptr);
};
#endif // MAINSCENE_H
