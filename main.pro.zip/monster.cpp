#include "monster.h"
#include <QDebug>

//怪物类函数实现
Monster::Monster(CoorStr **pointarr, int arrlength, int x, int y, int fid) :
    mx(x), my(y), id(fid)
{
    for(int i = 0; i < arrlength; i++)      //将传进来的数组插入到Waypoint动态数组
        Waypoint.push_back(pointarr[i]);



    switch (id)
    {
    case 1:
        health = 100;
        mwidth = 64;
        mheight = 64;
        ImgPath = ":/imagemonster1.png";
        break;
    case 2:
        health = 100;
        mwidth = 86;
        mheight = 64;
        ImgPath = ":/imagemonster2.png";
        break;
    }
}

//怪物按设定路径点移动
bool Monster::Move()
{
    if(Waypoint.empty())
        return true;

    //如果第一个路径点的y小于怪物原本的路径点，则怪物向下走
    if (Waypoint.at(0)->y > my) //下
    {
        my += mspeed;
        return false;
    }

    if (Waypoint.at(0)->x < mx) //左
    {
        mx -= mspeed;
        return false;
    }

    if (Waypoint.at(0)->x > mx) //右
    {
        mx += mspeed;
        return false;
    }

    if (Waypoint.at(0)->y < my) //上
    {
        my -= mspeed;
        return false;
    }

   //删除路径点
    if (Waypoint.at(0)->y == my && Waypoint.at(0)->x == mx)
    {

        Waypoint.erase(Waypoint.begin());

    }

    return false;
}


int Monster::GetX() const
{
    return mx;
}

int Monster::GetY() const
{
    return my;
}

int Monster::GetWidth() const
{
    return mwidth;
}

int Monster::GetHeight() const
{
    return mheight;
}

QString Monster::GetImgPath() const{
    return ImgPath;
}

int Monster::GetId() const
{
    return id;
}

int Monster::GetHealth() const
{
    return health;
}

void Monster::SetHealth(int fhealth)
{
    health = fhealth;
}

