#include "figure.h"
#include <QVector>
#include<QPainter>
Figure::Figure(QPoint pos,QString pixFileName):QObject (0),pixmap(pixFileName)
{
    _pos=pos;
    range=120;
    power=30;
    target=nullptr;


}
void Figure::draw(QPainter *painter)
{
     painter->save();
     painter->drawPixmap(_pos,pixmap);
     painter->setPen(Qt::red);
     painter->drawEllipse(_pos,range,range);
}



int Figure::GetRange() const
{
    return range;
}



int Figure::GetAttack() const
{
    return power;
}





