#ifndef FIGURE_H
#define FIGURE_H
#include<QPoint>
#include <QString>
#include<QPixmap>
#include<QTimer>
class Monster;
class Figure:public QObject
{
protected:
    QPoint _pos;
    QPixmap pixmap;   
    QString BaseImgPath;
    QString DefImgPath;  
    int range;
    QString BullPath;
    int power;
    int counter = 0;
    Monster *target;
public:
    void attack();
    void draw(QPainter *painter);
    Figure(QPoint pos,QString pixFileName);
    QTimer *rate;
    QString GetBaseImgPath() const;
    QString GetDefImgPath() const;
    int GetRange() const;
    void choosemonster(Monster *monster);
    int GetAttack() const;
    int SetRange();
    void runout();

    void SetBulletWidthHeight(int, int);
};
#endif // FIGURE_H
