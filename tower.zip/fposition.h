#ifndef FPOSITION_H
#define FPOSITION_H

#include <QVector>
#include<QPoint>
#include<QPainter>
//塔基
class Fposition
{public:
    Fposition(QPoint pos,QString path=(":/image/StoneBrick.png"));
    QPoint getCenterPos();
    QPoint getPos();
    bool ContainPos(QPoint pos);
    void draw(QPainter * painter) const;
    bool hasTower();
    void setHasTower(bool hasTower);
 private:
    QPoint m_pos;
    QString m_path;

    bool m_hasTower;
    static const QSize m_fixedSize;
};

#endif // FPOSITION_H
