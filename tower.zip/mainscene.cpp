#include "mainscene.h"
#include "ui_mainscene.h"
#include<QPushButton>
#include<QMainWindow>
#include<QPainter>
#include<QPaintEvent>
#include<QPushButton>
#include<QPoint>
#include<QTimer>
#include <QDebug>
#include<QString>
#include<figure.h>
#include <cmath>
#include<monster.h>
#include <QPushButton>
#include<QPixmap>
#include<QVector>
#include<globalstruct.h>
#include<waypoint.h>
#include<button.h>
#include<fposition.h>


MainScene::MainScene(QWidget *parent) :QMainWindow(parent), ui(new Ui::MainScene),
    money(1000),
    cumoney(1000),
    waves(0),
     life(10),
    win(false),
  lose(false)
{

    setFixedSize(1040, 640);
    ui->setupUi(this);
    loadTowerPosition();
    addWayPoints();
    QTimer * timer=new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(updateMap()));
    timer->start(30);
    QTimer::singleShot(300,this,SLOT(start()));

    QLabel *victorylable = new QLabel(this);
    victorylable->move(176, 180);
    victorylable->setFont(QFont("楷体", 110));
    victorylable->setText(QString("游戏胜利"));
    victorylable->hide();

}

void MainScene::mousePressEvent(QMouseEvent * event)
{
    QPoint pressPos=event->pos();
    auto it=positionList.begin();
    while(it!=positionList.end())
    {
        if(Qt::LeftButton==event->button())
        {
            if(it->ContainPos(pressPos) && !it->hasTower())
            {
                if(cumoney>=cost)
                {Figure * figure=new Figure(it->getPos(),":/image/goku.jpg");
                figureList.push_back(figure);
                cumoney-=cost;
                it->setHasTower(true);
                update();
                break;
                }
                else {
                   return;
                }
            }
        }
        ++it;
    }
}

void MainScene::addWayPoints()
{
    WayPoint *wayPoint1 = new WayPoint(QPoint(1000, 300));
    wayPointsList.push_back(wayPoint1);

    WayPoint *wayPoint2 = new WayPoint(QPoint(700, 300));
    wayPointsList.push_back(wayPoint2);
    wayPoint1->setNextWayPoint(wayPoint2);

    WayPoint *wayPoint3 = new WayPoint(QPoint(700, 480));
    wayPointsList.push_back(wayPoint3);
    wayPoint2->setNextWayPoint(wayPoint3);

    WayPoint *wayPoint4 = new WayPoint(QPoint(50, 480));
    wayPointsList.push_back(wayPoint4);
    wayPoint3->setNextWayPoint(wayPoint4);

    WayPoint *wayPoint5 = new WayPoint(QPoint(50, 200));
    wayPointsList.push_back(wayPoint5);
    wayPoint4->setNextWayPoint(wayPoint5);

    WayPoint *wayPoint6 = new WayPoint(QPoint(430, 200));
    wayPointsList.push_back(wayPoint6);
    wayPoint5->setNextWayPoint(wayPoint6);

    WayPoint *wayPoint7 = new WayPoint(QPoint(430, 5));
    wayPointsList.push_back(wayPoint7);
    wayPoint6->setNextWayPoint(wayPoint7);
}

void MainScene::DrawMapArr(QPainter& painter)
{

    int Map_1[16][26] =
    {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1,
        0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1,
        0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0,
        0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    };

    int Map[16][26];    //用于拷贝不同的关卡数组


    memcpy(Map, Map_1, sizeof(Map));


    for (int j = 0; j < 16; j++)
        for (int i = 0; i < 26; i++)
        {
            switch (Map[j][i])
            {
            case 0:
                painter.drawPixmap(i * 40, j * 40, 40, 40,
                    QPixmap(":/image/GrassBlock.png"));
                break;
            case 1:
                painter.drawPixmap(i * 40, j * 40, 40, 40,
                    QPixmap(":/image/GroundBlock.png"));
                break;
             case 2:

                painter.drawPixmap(i * 40, j * 40, 40, 40,
                    QPixmap(":/image/Shells3.png"));

            }
        }

}


void MainScene::loadTowerPosition()
{

    QPoint pos[]=
    {
        QPoint(690,450),
        QPoint(118,330),
        QPoint(10,300),
        QPoint(186,169),
        QPoint(314,169),
        QPoint(186,450),
        QPoint(314,450),
        QPoint(540,558)
    };
    int len=sizeof(pos)/sizeof(pos[0]);
    for(int i=0;i<len;i++)
    {
        positionList.push_back(pos[i]);
    }
}
void MainScene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    DrawMapArr(painter);
    foreach( Monster * monster,monsterList)
            monster->draw(&painter);
    foreach(Figure *figure,figureList)
              figure->draw(&painter);
    foreach(const Fposition towerposition,positionList)
           towerposition.draw(&painter);
    painter.setPen(Qt::red);
    painter.drawText(QRect(500,5,130,60),QString("Waves: %1").arg(waves+1));
    painter.drawText(QRect(30,5,130,60),QString("Life: %1").arg(life));
    painter.drawText(QRect(300,5,130,60),QString("Money: %1").arg(cumoney));


}

bool MainScene::loadwaves()
{
    if(waves>=6)
    {
        return false;
    }
    int enemyStartInterval[]={100,500,600,1000,3000,6000};
    for(int i=0;i<6;++i)
    {
        WayPoint * startWayPoint;
        startWayPoint=wayPointsList.first();
        Monster * monster=new Monster(startWayPoint,this);//创建一个新得enemy
        monsterList.push_back(monster);
        QTimer::singleShot(enemyStartInterval[i],monster,SLOT(active()));
    }
    return true;
}

void MainScene::start()
{
    loadwaves();
}

void MainScene::updateMap()
{
    foreach(Monster *monster, monsterList)
    monster->Move();
    update();
}

void MainScene::getHpDamaged()
{
    life-=1;
}

void MainScene::awardGlod()
{
    money+=200;
}

void MainScene::removeMonster(Monster *monster)
{
    Q_ASSERT(monster);
    monsterList.removeOne(monster);
    delete monster;
    if(monsterList.empty())
        {
            ++waves;
            if(!loadwaves())
            {
              win=true;            }
        }
}

QList<Monster *> MainScene::getmonsterList()
{
    return monsterList;
}

MainScene::~MainScene()
{
    delete ui;
}

