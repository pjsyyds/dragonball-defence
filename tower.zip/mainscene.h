#ifndef MAINSCENE_H
#define MAINSCENE_H
#include<QLabel>
#include <QWidget>
#include <QPainter>
#include <QMouseEvent>
#include <QTimer>
#include<QPoint>
#include "fposition.h"
#include "figure.h"
#include "monster.h"
#include<button.h>
#include <QLabel>
#include<QMainWindow>
class Figure;

namespace Ui {
class MainScene;
}

class MainScene : public QMainWindow
{
    Q_OBJECT
private:
     Ui::MainScene *ui;
    void mousePressEvent(QMouseEvent *);
    void addWayPoints();
    void paintEvent(QPaintEvent *);
    void DrawMapArr(QPainter&);
    int money = 1000;
    int cost=200;
    int cumoney=1000;
    int waves;
    int life = 10;
    const int RewardMoney = 20;
    QList<Fposition>  positionList;
    QList<WayPoint *>		wayPointsList;
    QList<Monster *>	    monsterList;
    QList<Figure *> figureList;
    QList<Monster*> getmonsterList();
public:
     void getHpDamaged();
     void awardGlod();
     void removeMonster(Monster * monster);
     void loadTowerPosition();
     bool loadwaves();
     bool win;
     bool lose;
    ~MainScene();
    explicit MainScene(QWidget *parent = nullptr);
private slots:
     void updateMap();
     void start();

};
#endif // MAINSCENE_H
