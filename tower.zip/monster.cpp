#include "monster.h"
#include <QDebug>
#include<waypoint.h>
#include<globalstruct.h>
#include "mainwindow.h"
#include <QPainter>
#include <QColor>
#include <QDebug>
#include <QMatrix>
#include <QVector2D>
#include <QtMath>
#include<mainscene.h>
//怪物类函数实现
const QSize Monster::m_fixedSize(22,23);

   Monster::Monster(WayPoint *startwaypoint,MainScene *game,QString pixFileName):
       QObject(0),
       pixmap(pixFileName),
       _game(game)

{        pos=startwaypoint->pos();
        health = 100;
          cuhealth=health;
            canact=true;
          speed=10;
 desWayPoint=startwaypoint->nextWayPoint();
}



   void Monster::Move()
   {
       if (canact==false)
           return;
       if (collisionWithCircle(pos, 1, desWayPoint->pos(), 1))
       {

           if (desWayPoint->nextWayPoint())
           {

               pos = desWayPoint->pos();
               desWayPoint = desWayPoint->nextWayPoint();
           }
           else
           {
              _game->getHpDamaged();
              _game->removeMonster(this);
              canact=false;
           }
       }
       QPoint targetPoint = desWayPoint->pos();
        double movementSpeed = speed;
       QVector2D normalized(targetPoint - pos);
       normalized.normalize();
       pos = pos + normalized.toPoint() * movementSpeed;



}
void Monster::active()
{
    canact = true;
}

void Monster::draw(QPainter *painter)
{if(!canact)
    {
        return;
   }
    QPoint healthBarPoint=_pos+QPoint(-m_fixedSize.width()/2,-m_fixedSize.height());
    painter->setPen(Qt::NoPen);
    painter->setBrush(Qt::red);
    QRect healthBarBackRect(healthBarPoint,QSize(40,2));
    painter->drawRect(healthBarBackRect);

    painter->setBrush(Qt::green);
    QRect healthBarRect(healthBarPoint,QSize((double)cuhealth/health*10,2));
    painter->drawRect(healthBarRect);

    QPoint tmp(_pos.x()-m_fixedSize.width()/2,_pos.y()-m_fixedSize.height()/2);
    painter->save();
   painter->drawPixmap(pos,pixmap);
}
