#ifndef MONSTER_H
#define MONSTER_H
#include <QVector>
#include <QString>
#include<QPixmap>
#include<QPoint>
#include<QObject>
class globalstruct;
class figure;
class WayPoint;
class QPainter;
class MainScene;
//怪物类
class Monster :public QObject
{
private:
    QPixmap pixmap;
    QPoint pos;
    QString ImgPath;
    int health;
    int cuhealth;
    qreal speed;
    WayPoint *		desWayPoint;
    MainScene *	_game;
private slots:
    void active();
public:
    bool canact;
    void betarget(figure *figure);
    void beattacted(int damage);
    void runawy(figure *figure);
    void deleted();
    void draw(QPainter *painter);
     Monster(WayPoint *startwaypoint,MainScene*game,QString pixFileName=":/image/monster2.png");
    void Move();
    QString GetImgPath() const;
    int GetHealth() const;
    void SetHealth(int);
    QPoint _pos;
     static const QSize m_fixedSize;
};

#endif // MONSTER_H
