#include "music.h"

 Music::Music(QWidget *parent) :
    QWidget(parent),

{
        playlist = new QMediaPlaylist;
        playlist->addMedia(":/8bitDungeonLevel.mp3"));
        playlist->addMedia(":/laser_shoot.mp3"));
        playlist->addMedia(":tower_place.mp3"));
        playlist->setCurrentIndex(1);
        player = new QMediaPlayer;
        player->setPlaylist(playlist);
        player->play();

}
Music::~Music()
{
    player->stop();
}
